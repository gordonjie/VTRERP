﻿using JN.K3.YDL.Core;
using Kingdee.BOS;
using Kingdee.BOS.App;
using Kingdee.BOS.App.Data;
using Kingdee.BOS.Core.Report;
using Kingdee.BOS.BusinessEntity;
using System;
using System.Data;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Kingdee.K3.FIN.AR.App.Report;
using Kingdee.BOS.Util;
using Kingdee.BOS.Contracts;
using Kingdee.K3.FIN.App.Core.ARAP.AbstractReport;
using Kingdee.K3.FIN.App.Core;
using Kingdee.K3.FIN.Core;
using Kingdee.BOS.Orm;


namespace VTR.K3.YDL.App.Report
{
    [Description("扩展-应收款明细表服务端插件")]




    public class JNARPAYDETAILREPORTService : ARDetailReportService
    {

        protected override void BuildData(string tableName)
        {

             base.BuildData(tableName);

                this.BuilderReportSql(tableName);
                //this.VTRUpdateRowDataEndBalance(tableName);
               // base.UpdateRowDataEndBalance(tableName);


        }








        private void BuilderReportSql(string tableName)
        {

            string addfieldSql = string.Format(@"/*dialect*/ alter table {0} add F_JN_Note varchar(250)  DEFAULT ''", tableName);
            DBUtils.Execute(this.Context, addfieldSql);

            string sql = string.Format(@"/*dialect*/ update {0} set F_JN_Note=''", tableName);
            DBUtils.Execute(this.Context, sql);

            sql = string.Format(@"/*dialect*/ update {0}  set F_JN_Note= table3.IVBillno  from
{1} as table1,
(select TB1.FID,TB1.IVBillno,TB2.FSRCBILLNO from 
(select FID,IVBillno=STUFF((select ','+FSRCBILLNO from T_AR_BillingMatchLogENTRY as T2
 where T1.FID=T2.FID and (FSOURCETYPE='1cab58bc33d24e27826be02249f4edac' or FSOURCETYPE='50ea4e69b6144f69961d2e9b44820929')
 FOR XML PATH('')), 1, 1, '')
from T_AR_BillingMatchLogENTRY  as T1
where (FSOURCETYPE='1cab58bc33d24e27826be02249f4edac' or FSOURCETYPE='50ea4e69b6144f69961d2e9b44820929')
group by FID ) TB1
join (select FID,FSRCBILLNO from T_AR_BillingMatchLogENTRY where FSOURCETYPE<>'50ea4e69b6144f69961d2e9b44820929' and FSOURCETYPE<>'1cab58bc33d24e27826be02249f4edac' and FSRCBILLNO not like 'ART%' ) TB2
on TB1.FID=TB2.FID) as table3
where table3.FSRCBILLNO=table1.FBILLNO", tableName, tableName);
            DBUtils.Execute(this.Context, sql);

            sql = string.Format(@"/*dialect*/ update {0}  set F_JN_Note= table3.IVBillno  from
{1} as table1,
(select TB1.FID,TB1.IVBillno,TB2.FSRCBILLNO from 
(select FID,IVBillno=STUFF((select ','+FSRCBILLNO from T_AR_BillingMatchLogENTRY as T2
 where T1.FID=T2.FID and (FSOURCETYPE='1cab58bc33d24e27826be02249f4edac' or FSOURCETYPE='50ea4e69b6144f69961d2e9b44820929'or FSOURCETYPE='180ecd4afd5d44b5be78a6efe4a7e041')
 FOR XML PATH('')), 1, 1, '')
from T_AR_BillingMatchLogENTRY  as T1
where (FSOURCETYPE='1cab58bc33d24e27826be02249f4edac' or FSOURCETYPE='50ea4e69b6144f69961d2e9b44820929'or FSOURCETYPE='180ecd4afd5d44b5be78a6efe4a7e041')
group by FID ) TB1
join (select FID,FSRCBILLNO from T_AR_BillingMatchLogENTRY where FSOURCETYPE<>'50ea4e69b6144f69961d2e9b44820929' and FSOURCETYPE<>'1cab58bc33d24e27826be02249f4edac' and FSRCBILLNO like 'ART%' ) TB2
on TB1.FID=TB2.FID) as table3
where table3.FSRCBILLNO=table1.FBILLNO", tableName, tableName);
            DBUtils.Execute(this.Context, sql);

        }



    }
}